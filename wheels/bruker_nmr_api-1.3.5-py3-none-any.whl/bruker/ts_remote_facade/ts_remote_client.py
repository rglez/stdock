from typing import List, Dict

import grpc
from google.protobuf.empty_pb2 import Empty
from remote_api import about_pb2_grpc as about_grpc
from remote_api import command_pb2_grpc as command_grpc
from remote_api import dataset_pb2_grpc as dataset_grpc
from remote_api import parameter_pb2_grpc as parameter_grpc
from remote_api.about_pb2 import TopspinVersionDto, TopspinInstallationPathDto
from remote_api.about_pb2_grpc import AboutServiceStub
from remote_api.command_pb2 import CommandDto
from remote_api.command_pb2_grpc import CommandServiceStub
from remote_api.dataset_pb2 import NMRDataInfoDto, DataSetPathDto, NMRDataDto, GetDataSetRequestDto, DataSetFileDto, \
    GetFileRequestDto, IntegrationRegionsDto, IndexRangesDto, GetDataSetWithIndexRangesRequestDto
from remote_api.dataset_pb2_grpc import DataSetServiceStub, PeakListServiceStub, IntegrationRegionsServiceStub
from remote_api.parameter_pb2 import ParameterDto, SetParameterDto, GetParametersDto
from remote_api.parameter_pb2_grpc import ParameterServiceStub

from bruker.model.nmr_model import NMRDataInfo, NMRData, Peak, DataSetFile, ApiException


class Configuration:
    _url: str = None

    def __init__(self, url: str):
        if url is None:
            self._url = "localhost:3081"
            return
        self._url = url

    def get_url(self) -> str:
        return self._url


def data_set(data_set_path: str) -> DataSetPathDto:
    return DataSetPathDto(datasetPath=data_set_path)


class NMRDataInfoMapper:
    @staticmethod
    def from_dto(dto: NMRDataInfoDto) -> NMRDataInfo:
        return {
            "dataset_path": dto.datasetPath.datasetPath,
            "raw_data_dimension": dto.rawDataDimension,
            "proc_data_dimension": dto.procDataDimension,
            "acquisition_date": dto.acquisitionDate.ToDatetime(),
            "acquisition_nuclei": {
                "direction1": dto.acquisitionNuclei.direction1,
                "direction2": dto.acquisitionNuclei.direction2
            },
            "spectrometer_frequency": float(dto.spectrometerFrequency),
            "solvent": dto.solvent,
            "pulse_program": dto.pulseProgram,
            "spec_typ": dto.specTyp,
            "title": dto.title
        }


class NMRDataMapper:
    @staticmethod
    def from_dto(dto: NMRDataDto) -> NMRData:
        return {
            "dataset_path": dto.datasetPath,
            "component": dto.component,
            "data_points": dto.dataPoints,
            "index_ranges": dto.indexRanges.indexRanges,
            "physical_ranges": dto.physicalRanges
        }


class DataSetFileMapper:
    @staticmethod
    def from_dto(dto: DataSetFileDto) -> DataSetFile:
        return {
            "name": dto.name,
            "path": dto.path,
            "content": dto.content
        }


def _handle_rpc_error(func):
    def rpc_error_mapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except grpc.RpcError as ex:
            raise ApiException(ex)
    return rpc_error_mapper


class TsRemoteClient:
    _channel: grpc.Channel = None
    _configuration: Configuration = None

    def __init__(self, configuration: Configuration):
        self._configuration = configuration
        self._channel = self.__get_channel()

    def __get_channel(self) -> grpc.Channel:
        max_message_length = 1024 * 1024 * 1024
        if self._channel is None:
            self._channel = grpc.insecure_channel(self._configuration.get_url(),
                                                  options=[('grpc.max_receive_message_length', max_message_length)])
        return self._channel

    # About Service
    def __get_about_service_stub(self) -> AboutServiceStub:
        return about_grpc.AboutServiceStub(self.__get_channel())

    @_handle_rpc_error
    def get_version(self) -> str:
        response: TopspinVersionDto = self.__get_about_service_stub().GetTopspinVersion(Empty())
        return response.version

    @_handle_rpc_error
    def get_installation_path(self) -> str:
        response: TopspinInstallationPathDto = self.__get_about_service_stub().GetTopspinInstallationPath(Empty())
        return response.installationPath

    # Command Service
    def __get_cmd_service_stub(self) -> CommandServiceStub:
        return command_grpc.CommandServiceStub(self.__get_channel())

    @_handle_rpc_error
    def execute_command(self, command: str, args: list[str] = None, data_set_path: str = None,
                        wait: bool = False) -> None:
        if args is None:
            args = []
        # TODO: deal with optional dataSetPath
        request: CommandDto = CommandDto(command=command, arguments=args, dataSetPath=data_set_path, wait=wait)
        self.__get_cmd_service_stub().ExecuteCommand(request)

    # DataSet Service
    def __get_data_set_service_stub(self) -> DataSetServiceStub:
        return dataset_grpc.DataSetServiceStub(self.__get_channel())

    @_handle_rpc_error
    def get_current_opened_data_set_info(self) -> NMRDataInfo:
        dto: NMRDataInfoDto = self.__get_data_set_service_stub().GetCurrentOpenedDataSetInfo(Empty())
        return NMRDataInfoMapper.from_dto(dto)

    @_handle_rpc_error
    def get_data_set_info(self, data_set_path: str) -> NMRDataInfo:
        dto: NMRDataInfoDto = self.__get_data_set_service_stub().GetDataSetInfo(data_set(data_set_path))
        return NMRDataInfoMapper.from_dto(dto)

    @_handle_rpc_error
    def get_data_set(self, data_set_path: str, component: str) -> NMRData:
        request: GetDataSetRequestDto = GetDataSetRequestDto(datasetPath=data_set(data_set_path), component=component)
        return NMRDataMapper.from_dto(self.__get_data_set_service_stub().GetDataSet(request))

    @_handle_rpc_error
    def get_data_set_with_index_ranges(self, data_set_path: str, component: str,
                                       filter_index_ranges_dto: IndexRangesDto) -> NMRData:
        request: GetDataSetWithIndexRangesRequestDto = GetDataSetWithIndexRangesRequestDto(
            dataSetRequest=GetDataSetRequestDto(datasetPath=data_set(data_set_path), component=component),
            filterIndexRanges=filter_index_ranges_dto)
        return NMRDataMapper.from_dto(self.__get_data_set_service_stub().GetDataSetWithIndexRanges(request))

    @_handle_rpc_error
    def get_proc_file(self, data_set_path: str, file_name: str) -> DataSetFile:
        request: GetFileRequestDto = GetFileRequestDto(datasetPath=data_set(data_set_path), fileName=file_name)
        return DataSetFileMapper.from_dto(self.__get_data_set_service_stub().GetProcFile(request))

    @_handle_rpc_error
    def get_raw_file(self, data_set_path: str, file_name: str) -> DataSetFile:
        request: GetFileRequestDto = GetFileRequestDto(datasetPath=data_set(data_set_path), fileName=file_name)
        return DataSetFileMapper.from_dto(self.__get_data_set_service_stub().GetRawFile(request))

    @_handle_rpc_error
    def get_structure_file(self, data_set_path: str) -> DataSetFile:
        request: GetFileRequestDto = GetFileRequestDto(datasetPath=data_set(data_set_path))
        return DataSetFileMapper.from_dto(self.__get_data_set_service_stub().GetStructureFile(request))

    # Parameter Service
    def __get_parameter_service_stub(self) -> ParameterServiceStub:
        return parameter_grpc.ParameterServiceStub(self.__get_channel())

    @_handle_rpc_error
    def get_parameters(self, data_set_path: str, keys: list[str]) -> Dict:
        request: GetParametersDto = GetParametersDto(datasetPath=data_set_path, parameterKeys=keys)
        return {p.key: p.value for p in self.__get_parameter_service_stub().GetParameters(request).parameters}

    @_handle_rpc_error
    def set_parameter(self, data_set_path: str, key: str, value: str) -> None:
        request: SetParameterDto = SetParameterDto(datasetPath=data_set_path,
                                                   parameter=ParameterDto(key=key, value=value))
        self.__get_parameter_service_stub().SetParameter(request)

    # PeakList Service
    def __get_peak_list_service_stub(self) -> PeakListServiceStub:
        return dataset_grpc.PeakListServiceStub(self.__get_channel())

    @_handle_rpc_error
    def get_peak_list(self, data_set_path: str) -> List[Peak]:
        return [{"position": p.position,
                 "intensity": p.intensity,
                 "type": p.type,
                 "annotation": p.annotation
                 } for p in self.__get_peak_list_service_stub().GetPeakList(data_set(data_set_path)).peaks]

    # IntegrationRegions Service
    def __get_integration_regions_service_stub(self) -> IntegrationRegionsServiceStub:
        return dataset_grpc.IntegrationRegionsServiceStub(self.__get_channel())

    @_handle_rpc_error
    def get_integration_regions(self, data_set_path: str) -> IntegrationRegionsDto:
        return self.__get_integration_regions_service_stub().GetIntegrationRegions(data_set(data_set_path))
