#
# implementation of 1D and 2D plot
#

from bruker.data.nmr  import *

from adjustText import adjust_text
import re

from matplotlib import pyplot as plt
from matplotlib.ticker import AutoMinorLocator

def plot_1d_spectrum(spectrum:NMRDataSet, lw = 0.5, color ='blue',
                     put_yaxis_right = True,
                     show_yaxis = True,
                     region = None, show_title = False,
                     peaks={}, showpeaks = False, peakmarkers = True, peakfontsize = 8,
                     ax_font_size = 14, tick_font_size = 12):
    '''
    Plot 1D spectrum.

    :param show_yaxis:
    :param spectrum: NMRDataSet object
    :param lw:
    :param color:
    :param put_yaxis_right:
    :param region: array of float numbers specifying the left and right limit for plotting in ppm.
    :param show_title:
    :param peaks:
    :param showpeaks:
    :param peakmarkers:
    :param peakfontsize:
    :param ax_font_size:
    :param tick_font_size:
    :return:
    '''
    # this sets the defult - do not consider vertical scale
    left_y = 0
    right_y = 0

    if region is not None:
        left_x = region[0]
        right_x = region[1]
    else:
        #   read the displayed region
        left_x = float(spectrum.getPar("F1P"))
        right_x = float(spectrum.getPar("F2P"))
        # read the corresponding vertical scale - stored as USERP10
        try:
            minmax_y = numpy.array(re.split("[|]", spectrum.getPar('USERP10')), dtype='float')
            left_y = minmax_y[0]
            right_y = minmax_y[1]
        except:
            # ignore any exceptions
            pass

    # set the plot limits
    plt.xlim(left_x, right_x)
    if left_y != right_y:
        plt.ylim(left_y, right_y)

    # read the corresponding data points
    specData = spectrum.getSpecDataPoints(physRange=[PhysicalRange(left_x, right_x)])

    if specData.get(EXCEPTION):
        print('Error :', specData.get(EXCEPTION).details())
        exit(-1)

    axis_font = {'size': str(ax_font_size), 'style': 'italic'}
    ax = plt.gca()
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())

    if put_yaxis_right:
        ax.yaxis.set_label_position("right")
        ax.yaxis.tick_right()

    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontsize(tick_font_size)

    delta = spectrum.getSW() / int(spectrum.getPar("status SI"))

    # plot the requested region, independent on the data resolution
    # axis uses the physical coordinates from data points, not the region
    pr = specData['physicalRanges'][0]
    axis = numpy.linspace(float(pr['start']), float(pr['start'])-delta*(len(specData['dataPoints']) - 1), len(specData['dataPoints']))
    # vertical scale may be also set
    # plt.ylim(-1e5, 3e6)

    if put_yaxis_right:
        plt.gca().yaxis.set_label_position("right")
        plt.gca().yaxis.tick_right()

    plt.gca().yaxis.set_visible(show_yaxis)

    # plot spectrum
    plt.plot(axis, specData['dataPoints'],  linewidth=lw, color = color)

    # read the axis names as used in TopSpin
    unit_x = spectrum.getPar("status AXUNIT")
    if not unit_x:
        unit_x = 'ppm'

    plt.xlabel(spectrum.getPar("status AXNUC") + ' (' + unit_x + ')', **axis_font)

    if showpeaks:
        texts = []
        markers = []

        idx = 1
        for p in peaks:
            # use peak numbers if peaks have no annotations
            if not p['annotation']:
                p['annotation'] = str(idx)
            idx = idx + 1

            # check if peak is visible within current limits
            pos = p['position']
            if pos[0] > left_x or pos[0] < right_x:
                continue

            plt.plot([pos[0],pos[0]],[0,1e7], color = 'red')

            if peakmarkers:
                markers.append(plt.plot(pos[0], 0, marker='+', markersize=3, color="red", lw=0.2))

    if show_title:
        # put the title on the spectrum
        plt.text(left_x - 0.01, plt.gca().get_ylim()[1], spectrum.getInfo()['title'], verticalalignment='top', color='red')

    return plt.gcf()


#
# Plot 2D spectrum as a contour plot
#
def plot_2d_spectrum(spectrum: NMRDataSet,
                     lw:float = 0.5, color = ('blue', 'green'),
                     put_yaxis_right:bool = True,
                     region = None,
                     show_title = False,
                     peaks={},
                     showpeaks = False, peakmarkers = False,
                     peakfontsize = 8,ax_font_size = 14, tick_font_size = 12):
    '''
    Plot 2D spectrum

    :param spectrum:
    :param lw:
    :param color:
    :param put_yaxis_right:
    :param region: array of 4 float numbers specifying the left and right limit for plotting in ppm ([left_x, right_x, bottom_y, upper_y])
    :param show_title:
    :param peaks:
    :param showpeaks:
    :param peakmarkers:
    :param peakfontsize:
    :param ax_font_size:
    :param tick_font_size:
    :return:
    '''

    if region is not None:
        left_x = region[0]
        right_x = region[1]
        left_y = region[2]
        right_y = region[3]
    else:
        #
        #  get the displayed part of the spectrum
        #
        left_x = float(spectrum.getPar("2 F1P"))
        right_x = float(spectrum.getPar("2 F2P"))

        left_y = float(spectrum.getPar("1 F1P"))
        right_y = float(spectrum.getPar("1 F2P"))

    if left_x == right_x or left_y == right_y:
        raise Exception('The displayed region is not well defined')

    specData = spectrum.getSpecDataPoints(physRange=[PhysicalRange(left_x, right_x), PhysicalRange(left_y, right_y)])

    if specData.get(EXCEPTION):
        print('Error :', specData.get(EXCEPTION).details())
        exit(-1)
    #
    # reshape the linear array to a 2D matrix
    #
    si1 = int(specData['indexRanges'][0]['numberOfPoints'])
    si2 = int(specData['indexRanges'][1]['numberOfPoints'])

    values = numpy.array(specData['dataPoints'])
    values = values.reshape(si2, si1)

    # read the contour levels from TopSpin
    contourLevels = numpy.array(re.split("[|]", spectrum.getPar('LEVELSPAR LEVELS')),dtype = 'float')
    contourLevels.sort()
    #
    # create corresponding colors array
    #
    colors = []
    for l in contourLevels:
        if float(l) > 0.:
            colors.append(color[0])
        else:
            colors.append(color[1])

    #
    # axes
    #
    # read the axis names as used in TopSpin
    unit_x = spectrum.getPar("2s AXUNIT")
    if not unit_x:
        unit_x = 'ppm'

    unit_y = spectrum.getPar("1s AXUNIT")
    if not unit_y:
        unit_y = 'ppm'

    xlabel = spectrum.getPar("2s AXNUC") + ' (' + unit_x + ')'
    ylabel = spectrum.getPar("1s AXNUC") + ' (' + unit_y + ')'

    axis_font = {'size': str(ax_font_size), 'style': 'italic'}

    ax = plt.gca()
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())

    if put_yaxis_right:
        ax.yaxis.set_label_position("right")
        ax.yaxis.tick_right()

    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontsize(tick_font_size)

    plt.xlabel(xlabel,  **axis_font)
    plt.ylabel(ylabel,  **axis_font)

    #
    #   reorder the parameters to fit the NMR standard
    #
    # invert the f1 axis according nmr conventions, do not do this for s
    if left_x < right_x and unit_x != 's':
        tmp = left_x
        left_x = right_x
        right_x = tmp

    # invert the f1 axis according nmr conventions, do not do this for s
    if left_y < right_y and unit_y != 's':
        tmp = left_y
        left_y = right_y
        right_y = tmp

    plt.xlim(left_x, right_x)
    plt.ylim(left_y, right_y)

    delta_x = spectrum.getSW() / int(spectrum.getPar("status SI"))
    delta_y = float(spectrum.getPar("1s SW_p")) / float(spectrum.getPar("1s SF")) / int(spectrum.getPar("1s SI"))

    pr = specData['physicalRanges'][0]
    axis_x = numpy.linspace(float(pr['start']), float(pr['start']) - delta_x * (si1 - 1), si1)
    pr = specData['physicalRanges'][1]
    axis_y = numpy.linspace(float(pr['start']), float(pr['start']) - delta_y * (si2 - 1), si2)

    plt.contour(axis_x, axis_y, values, contourLevels, linewidths= lw, colors=colors)

    if showpeaks:
        texts = []
        markers = []

        idx = 1
        for p in peaks:
            # use peak numbers if peaks have no annotations
            if not p['annotation']:
                p['annotation'] = str(idx)
            idx = idx + 1

            # check if peak is visible within current limits
            pos = p['position']
            if pos[0] > left_x or pos[0] < right_x or pos[1] > left_y or pos[1] < right_y:
                continue

            #txt = ax.text(pos[0], pos[1], re.search("([A-Z]*[0-9]*)", p['annotation']).group(0), color='black', fontsize=peakfontsize)
            # txt = ax.annotate('%s' % re.search("([A-Z][0-9]*)", p['annotation']).group(0), xy=p['position'], xycoords='data',
            #            xytext=(6, 3), textcoords='offset points', arrowprops=dict(arrowstyle="wedge", color='black', lw=0.1),
            #            bbox=dict(pad=-1, fc='none', ec='none'), size=4, horizontalalignment='left', verticalalignment='bottom')

            #txt.set_path_effects([PathEffects.withStroke(linewidth=0.5, foreground='w')])
            #texts.append(txt)

            if peakmarkers:
                markers.append(plt.plot(pos[0], pos[1], marker='+', markersize=3, color="red", lw=0.2))

            #plt.plot(peak['position'][0], peak['position'][1], 'x', color = 'C4')


    if show_title:
        # put the title on the spectrum
        plt.text(left_x - 0.01, ax.get_ylim()[1], spectrum.getInfo()['title'], verticalalignment='top', color='red')

    # Make sure peak lables dont overlap
    if showpeaks:
        adjust_text(texts, autoalign=True,
                    arrowprops=dict(arrowstyle="wedge, tail_width=0.2, shrink_factor=0.5", color='black', lw=0.1,
                                    alpha=0.5), lim=100, expand_text=(1.5, 1.5), expand_points=(1.3, 1.3))

    return plt.gcf()
