import glob
import os
import typing
from pathlib import PurePath, PureWindowsPath

from bruker.data.nmr import *
from bruker.ts_remote_facade import ts_remote_client as api

DataProvider = typing.NewType("DataProvider", None)
Display = typing.NewType("Display", None)

class Topspin:

    def __init__(self, url="localhost:3081"):
        configuration = api.Configuration(url)
        self.apiClient = api.TsRemoteClient(configuration)

    # Get the instance of a DataSetProvider
    def getDataProvider(self) -> DataProvider:
        return DataProvider(self)

    # Get the instance of display controller
    def getDisplay(self) -> Display:
        '''

        :return: The instance of Display object.
        '''
        return Display(self)

    #   Execute command in TopSpin
    def executeCommand(self, command: str, dataset_path:str=None, args: []= None, wait:bool = False):
        '''
        Issue a TopSpin command. The command syntax is the same as commands used in the TopSpin command line.

        :param command: The command to be executed
        :param dataSet: Optional path of data set on which the command should be executed
        :param args: an array of arguments
        :param wait: wait until the command finished
        :return:
        '''
        if args is None:
            args = []
        self.apiClient.execute_command(command=command, args=args, data_set_path=dataset_path, wait=wait)

    # Get the version of TopSpin
    def getVersion(self) -> str:
        return self.apiClient.get_version()

    # Get the installation path of TopSpin
    def getInstallationDirectory(self) -> str:
        '''

        :return: The TopSpin installation folder as /opt/topspin or c:\\bruker\\topspin
        '''
        return self.apiClient.get_installation_path()

    # Show an message dialog in TopSpin
    def showMessage(self, message_text: str):
        self.executeCommand("_show_message",args = [message_text])

    # Show an error dialog in TopSpin
    def showError(self, message_text: str):
        self.executeCommand("_show_message",args = ["x|"+ message_text])

    def getSpectrometerInterface(self):
        return Spectrometer(self)

###############################################################################
#
# Interface to get a Topspin dataset
#
class DataProvider:

    # data dimensions
    FIND_ANY = "Any"
    FIND_1D_2D = "1D+2D"
    FIND_1D = "1D"
    FIND_2D = "2D"
    FIND_ND = "nD"

    """ This class provides data set search and handling functionality """
    def __init__(self, top: Topspin):
        self._top = top

    #
    # internal shortcut - direct parameter access for search
    #
    def __get_parameter_value__(self,file_name, parameter):
        string_to_search = '##$' + parameter + '='
        # Open the file in read only mode
        with open(file_name, 'r') as read_obj:
            # Read all lines in the file one by one
            for line in read_obj:
                # For each line, check if line contains the string
                if line.startswith(string_to_search):
                    return line.lstrip(string_to_search).strip()

        return None

    #
    # Find NMR data sets with specified attributes
    #
    def find(self, directory:str, name:str='*', expno:int='*', procno:int='*', user:str=None, title:str=None,
             pulprog:str=None, dim=FIND_ANY, spectyp=None) ->list[str]:
        '''

        :param directory:
        :param name:
        :param expno:
        :param procno:
        :param user:
        :param title:
        :param pulprog:
        :param dim:
        :param spectyp:
        :return:
        '''

        if not name:
            name = '*'

        if not expno:
            expno = '*'

        if not procno:
            procno = '*'

        searchFile = 'procs'

        if dim == self.FIND_2D:
            searchFile = 'proc2s'

        searchString = os.path.sep +name + os.path.sep + str(expno) + os.path.sep + 'pdata' + os.path.sep + str(procno) + os.path.sep + searchFile

        res = []

        # we support both directory and list of directories
        if isinstance(directory,str):
            directory = [directory]

        for d in directory:
            tmp = glob.glob(d + searchString)

            for p in tmp:
                p2 = os.path.dirname(p)

                # skip all nD a 1D is required
                if dim == self.FIND_1D and os.path.exists (p2 + os.path.sep + 'proc2s'):
                    continue

                # skip all 3d and 4d
                if dim == self.FIND_2D and os.path.exists (p2 + os.path.sep + 'proc3s'):
                    continue

                if spectyp:
                    #
                    # check if the procs file contains ##$SPECTYP= <spectyp>
                    #
                    value = self.__get_parameter_value__(p2 + os.path.sep + 'procs', 'SPECTYP')
                    if value is None or value.strip('<>') != spectyp:
                        continue

                res.append(p2)

        return res

    def getNMRData(self, path:str, directIO = False) -> NMRDataSet:
        """
        A safe method to create the NMRDataSet object.

        :param path: data set path
        :param directIO: the return NMRData object is an instance of NMRDataSetDirect using direct I/O to access the data vectors
        :return: NMRDataSet object, or None if the datasets does not exist
        """
        try:
            if directIO:
                from bruker.data.direct_io import NMRDataSetDirect
                return NMRDataSetDirect(self._top, path)
            else:
                return NMRDataSet(self._top, path)
        except ApiException:
            return None


    def getCurrentDatasetIdentifier(self) -> str:
        '''
        Get the identifier of the data set visible on the screen  (current data set)

        :return: identifier of the NMR data set currently shown in TopSpin
        '''
        try:
            return self._top.apiClient.get_current_opened_data_set_info()['dataset_path']
        except ApiException as ex:
            if ex.code() == grpc.StatusCode.FAILED_PRECONDITION:
                return None
            else:
                raise ex

    def getNextEXPNO(self, identifier, increment=1):
        tmp = self.splitIdentifier(identifier)
        tmp[2] = str(int(tmp[2]) + increment)
        return self.composeIdentifier(tmp)

    def splitIdentifier(self, identifier):
        '''
        Split the NMR identifier in the traditional components - path, name, expno and procno
        :param identifier:
        :return: an array containing the data set path, name, expno and procno
        '''

        # this does not worked properly
        # if identifier.find('\\') >= 0:
        #     return PureWindowsPath(identifier).parts
        # else:
        #     return PurePath(identifier).parts

        if identifier.find('\\') >= 0:
            res =  identifier.replace('/','\\').rsplit('\\',4)
        else:
            res = identifier.rsplit('/',4)

        # remove the pdata from the list
        res.remove('pdata')

        return res

    def composeIdentifier(self, comp):
        '''
        compose a data set identifier (path) from an array of components - path, name, expno and procno
        :param comp: array of name components
        :return: the data set identifier (path)
        '''
        return os.path.join(comp[0], os.path.join(comp[1], os.path.join(comp[2], os.path.join('pdata', comp[3]))))


    def modifyIdentifier(self, identifier, procno = None, expno = None, name = None, path = None):
        '''
        Return a modified data set identifier
        :param path:
        :param identifier:
        :param procno:
        :param expno:
        :param name:
        :return:
        '''
        tmp = self.splitIdentifier(identifier)

        if path is not None:
            tmp[0] = path

        if name is not None:
            tmp[1] = name

        if expno is not None:
            tmp[2] = str(expno)

        if procno is not None:
            tmp[3] = str(procno)

        return self.composeIdentifier(tmp)

    def getCurrentDataset(self) -> NMRDataSet:
        '''
        Get the data set visible on the screen as a NMRData object

        :return: the NMRData object representing the data set currently shown in TopSpin, or None.
        '''
        cd = self.getCurrentDatasetIdentifier()
        if cd is None:
            return None
        else:
            return self.getNMRData(cd)

    #
    # Create new NMR data set
    # Creates a new parameter test and reads corresponding parameter
    #
    def createNMRData(self, path:str ,name:str, expno:int = 1, procno:int = 1, parameter:str = None):
        '''
        Safe creation of TopSpin data set.

        :param path: a full path of the data set to be created. e.g. /Bruker/Data/john
        :param name: data set name like MySample
        :param expno: experiment number
        :param procno: processing number
        :param parameter:
        :return: the instance of the created data set or None in the case of an error
        '''

        cmd = "new "+path+'|' + name +'|' + str(expno) + '|' + str(procno)

        self._top.executeCommand(cmd,wait=True)

        res = self.getNMRData(path+'/' + name +'/' + str(expno) + '/pdata/' + str(procno))

        if parameter is not None:
            res.launch('rpar '+parameter + ' all')

        return res



#############################################

class Spectrometer:
    def __init__(self, top):
        self._top = top

    def isSampleInMagnet(self):
        return None

    def isSampleLocked(self):
        return None

    def getSampleTemperature(self):
        return None

    def getAcquisitionStatus(self):
        return None

    def isConnectedToRealHardware(self):
        return None

class Display:

    def __init__(self, top:Topspin):
        self._top = top

    #
    # Show a NMRDataSet in Topspin
    #
    def show(self,dataset, newWindow = True):
        """
        Display a NMR data set in Topspin.
        :param dataset: NMRDataSet object or dat set identifier (path)
        :param newWindow:
        :return:
        """
        if newWindow:
            cmd = "rew"
        else:
            cmd = "re"

        if isinstance(dataset, str):
            # string - this is a data set identifier
            self._top.executeCommand(cmd + " " + dataset, wait=True)
        else:
            self.show(dataset.getIdentifier(),newWindow = newWindow)

    def arrangeWindowsHorizontal(self):
        self._top.executeCommand("arrangehori")

    def arrangeWindowsVertical(self):
        self._top.executeCommand("arrangevert")

    def arrangeWindowsMatrix(self):
        self._top.executeCommand("arrange")

    def closeAllWindows(self):
        self._top.executeCommand("closeall")
