import os
import sys

import array
import numpy

from bruker.data.nmr import NMRDataSet, \
    PROCDATA, PROCDATA_IMAG, PROCDATA_MIX_IR, PROCDATA_MIX_RI,\
    RAWDATA, IndexRange, PhysicalRange

# constant used to scale double data in the int32 buffer
SCALE_D_TO_INT = 2**29

class NMRDataSetDirect(NMRDataSet):
    '''
    NMR Data set object using direct I/O for reading and writing of data vectors.
    The parameter handling uses TopSpin. This is still experimental feature in TopSpin 4.2.*
    '''

    def __init__(self, top, path, use_direct_read = True):
        super().__init__(top, path)
        self.use_direct_read = use_direct_read

    #
    # direct reading of data vectors from the disc
    #
    def getDataVector1D(self,component, indexRanges:[], precision):
        '''
        Read the 1D dataset direct from the disc
        :param component:
        :param indexRanges:
        :param precision:
        :return:
        '''

        if not self.use_direct_read:
            return super().getDataVector(component, indexRanges, precision)

        if self.getDimension() > 1:
            return self.getDataVector2D(component, indexRanges, precision)

        try:
            if component == PROCDATA:
                f = self._path + '/1r'
                nc = int(self.getPar('status NC_proc'))
                type = int(self.getPar('status DTYPP'))
                byte_order = int(self.getPar('status BYTORDP'))
                number_of_points = int(self.getPar('status SI'))
            elif component == PROCDATA_IMAG:
                f = self._path + '/1i'
                nc = int(self.getPar('status NC_proc'))
                type = int(self.getPar('status DTYPP'))
                byte_order = int(self.getPar('status BYTORDP'))
                number_of_points = int(self.getPar('status SI'))
            elif component == RAWDATA:
                f = self._path + '/../../fid'
                nc = int(self.getPar('status NC'))
                type = int(self.getPar('status DTYPA'))
                byte_order = int(self.getPar('status BYTORDA'))
                number_of_points = int(self.getPar('status TD'))
            else:
                raise Exception('Unknown component ' + component)

            if byte_order == 0:
                # little endian
                bc = '<'
            else:
                # big endian
                bc = '>'

            if type == 0:
                # integer
                scale = 2 ** nc
                res2 = numpy.fromfile(f, dtype=numpy.dtype(bc + 'i4'), count=number_of_points).astype('f8') * scale
            elif type == 2:
                # double
                res2 = numpy.fromfile(f, dtype=numpy.dtype(bc + 'f8'), count=number_of_points)
            else:
                raise Exception('Unsupported data type  ' + component)

            if indexRanges is None:
                # reading the whole data vector
                indexRanges = [IndexRange(0,number_of_points)]
            else:
                # reading part of it - truncate the vector
                res2 = res2[indexRanges[0].getStart():indexRanges[0].getStart()+indexRanges[0].getNum()]

            if component == RAWDATA:
                ph = None
            else:
                ph = PhysicalRange(self.getPhysicalFromIndex(indexRanges[0].getStart()),
                                   self.getPhysicalFromIndex(indexRanges[0].getStart() + indexRanges[0].getNum()))

            return {'indexRanges': indexRanges, 'physicalRanges': ph, 'dataPoints': numpy.asarray(res2,precision)}

        except Exception as ex:
            return {'exc':ex}

    def getDataVector2D(self, component, indexRanges: [], precision):
        '''
        Read the 2D data vector using the direct I/O from disc

        :param component:
        :param indexRanges:
        :param precision:
        :return:
        '''

        if not self.use_direct_read:
            return super().getDataVector(component, indexRanges, precision)

        try:
            if component == PROCDATA:
                f = self._path + '/2rr'
                nc = int(self.getPar('status NC_proc'))
                type = int(self.getPar('status DTYPP'))
                byte_order = int(self.getPar('status BYTORDP'))
            elif component == PROCDATA_IMAG:
                f = self._path + '/2ii'
                nc = int(self.getPar('status NC_proc'))
                type = int(self.getPar('status DTYPP'))
                byte_order = int(self.getPar('status BYTORDP'))
            elif component == PROCDATA_MIX_IR:
                f = self._path + '/2ir'
                nc = int(self.getPar('status NC_proc'))
                type = int(self.getPar('status DTYPP'))
                byte_order = int(self.getPar('status BYTORDP'))
            elif component == PROCDATA_MIX_RI:
                f = self._path + '/2ri'
                nc = int(self.getPar('status NC_proc'))
                type = int(self.getPar('status DTYPP'))
                byte_order = int(self.getPar('status BYTORDP'))
            elif component == RAWDATA:
                f = self._path + '/../../ser'
                nc = int(self.getPar('status NC'))
                type = int(self.getPar('status DTYPA'))
                byte_order = int(self.getPar('status BYTORDA'))
            else:
                raise Exception('Unknown component ' + component)

            if byte_order == 0:
                # little endian
                bc = '<'
            else:
                # big endian
                bc = '>'

            if type == 0:
                # integer
                scale = 2 ** nc
                res2 = numpy.fromfile(f, dtype=numpy.dtype(bc + 'i4')).astype('f8') * scale
            elif type == 2:
                # double
                res2 = numpy.fromfile(f, dtype=numpy.dtype(bc + 'f8'))
            else:
                raise Exception('Unsupported data type  ' + component)

            if component != RAWDATA:

                #
                #  get rid of sub matrices
                #
                xdim = int(self.getPar('2s XDIM'))
                ydim = int(self.getPar('1s XDIM'))

                six = int(self.getPar('2s SI'))
                siy = int(self.getPar('1s SI'))

                # extract the sumbatrices - this creates a list submatrices
                # the python counts first rows - the xdim is at the end
                subs = res2.reshape([six // xdim * siy // ydim, ydim, xdim])
                rdata = numpy.empty((siy, six), dtype=res2.dtype)

                # put the sumbatrices in their place
                for subindex, sub in enumerate(subs):
                    # coordinates for placing of the submatrix
                    i2 = subindex % (six // xdim)
                    i1 = subindex // (six // xdim)
                    rdata[i1 * ydim:(i1 + 1) * ydim, i2 * xdim:(i2 + 1) * xdim] = subs[subindex]

                # extract the required index range
                if indexRanges is not None:
                    rdata = rdata[indexRanges[1].getStart():indexRanges[1].getStart()+indexRanges[1].getNum(),
                           indexRanges[0].getStart():indexRanges[0].getStart()+indexRanges[0].getNum()]
                else:
                    # set the index range to full size
                    indexRanges = [IndexRange(0,six),IndexRange(0,siy)]

                # get the data as an 1D array
                rdata = rdata.flatten(order='K')
            else:
                rdata = res2

            return {
                'indexRanges': indexRanges,
                'physicalRanges': None,
                'dataPoints': rdata
            }

        except Exception as ex:
            return {'exc':ex}

    #
    # direct read of data vectors from the disc
    #
    def getDataVector(self, component, indexRanges:[], precision):

        if self.use_direct_read:
            if self.getDimension() == 1:
                return self.getDataVector1D(component, indexRanges, precision)

            if self.getProcDim() == 2:
                return self.getDataVector2D(component, indexRanges, precision)

        return super().getDataVector(component, indexRanges, precision)

    def _calculate_scale(self, data_vector):
        maximum = max(abs(numpy.min(data_vector)), abs(numpy.max(data_vector)))
        nc = 0
        if maximum > SCALE_D_TO_INT:
            while maximum > SCALE_D_TO_INT:
                nc += 1
                maximum /= 2
        else:
            while maximum < SCALE_D_TO_INT:
                nc -= 1
                maximum *= 2

        return nc
    #
    #
    #
    def _write_int_to_disc(self, f, data_vector, nc = None):

        if nc is None:
            nc = self._calculate_scale(data_vector)

        d2 = numpy.asarray(data_vector) / 2 ** nc
        d3 = d2.astype('i4')
        d3.tofile(f)

        self.setPar('status NC_proc',nc)
        self.setPar('status YMAX_p', str(numpy.max(d3)))
        self.setPar('status YMIN_p', str(numpy.min(d3)))
        self.setPar('status DTYPP', 0)
        # set the byte order used to write the file
        if sys.byteorder == 'little':
            self.setPar('status BYTORDP', 0)
        else:
            self.setPar('status BYTORDP', 1)


    def setDataVector(self, component, data_vector, imag_part = None,audit_comment='Modified from python script'):

        if component == PROCDATA and self.getProcDim() > 1:
            raise Exception('Currently, only 1D processed data could be written')

        if component == PROCDATA:
            auditc = self._path + '/auditc.txt'
            audit_command = 'xcpr gdcheck comment'

            if imag_part is None:
                #
                # We are writing only real part
                #
                self._write_int_to_disc(self._path + '/1r',data_vector)
                #
                # delete the 1i
                #
                if os.path.isfile(self._path + '/1i'):
                    os.remove(self._path + '/1i')

            else:
                #
                # write both real and imaginary part
                #

                # need common nc for both imaginary
                nc = self._calculate_scale(numpy.append(data_vector,imag_part))
                # write imaginary part first - maximum and minimum are written in 1r
                self._write_int_to_disc(self._path + '/1i', imag_part, nc = nc)
                self._write_int_to_disc(self._path + '/1r', data_vector, nc=nc)

        elif component == RAWDATA:

            if imag_part is not None:
                raise Exception('Imaginary part cannot be set when writing RAWDATA')

            if self.getDimension() == 1:
                # always written as double
                f = self._path + '/../../fid'
                self.setPar('status TD', len(data_vector))
            else:
                # the data must be already aligned to 1024 byte boundary!
                f = self._path + '/../../ser'

            auditc = self._path + '/../../auditc.txt'
            audit_command = 'xcpr gdcheck raw comment'

            self.setPar('status NC',0)
            self.setPar('status DTYPA',2)

            # set the byte order used to write the file
            if sys.byteorder == 'little':
                self.setPar('status BYTORDA', 0)
            else:
                self.setPar('status BYTORDA', 1)

            # write the fid to the disc
            data_vector.tofile(f)

        else:
            raise Exception('Unsupported component ' + component)

        # write the audit entry to disc
        # this fails if the correponding audit file does not exists
        # with open(auditc, 'w') as f:
        #     f.write(audit_comment)
        #     f.close()
        #
        # self.launch(audit_command)